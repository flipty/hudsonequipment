// =============================================================================
// README.TXT
// -----------------------------------------------------------------------------
// Product information.
// =============================================================================

Thank you for choosing to use X!

For the latest product information, make sure to register for access to our
member area where we provide extensive documentation and all official support:

http://theme.co/x/go/register.php