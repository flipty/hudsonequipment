<?php

/**
 * See config/builder/keybindings.php for original notes.
 */

return array();