<?php
class Cornerstone_Control_Undefined extends Cornerstone_Control {

}